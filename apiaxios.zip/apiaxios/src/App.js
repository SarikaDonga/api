import './App.css';
import ProductList from './fetchmethod/ProductList';
function App() {
  return (
    <div >
      {/* using axios------------------- */}
       {/* <ProductList/> */}

      {/* using Fetch------------------- */}
      {/* <ProductList/> */}

      {/*  redux using axois*/}
    </div>
  );
}

export default App;
