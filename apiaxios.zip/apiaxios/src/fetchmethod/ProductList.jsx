import React, { useState, useEffect } from 'react';

const ProductList = () => {
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
  
    useEffect(() => {
        // Fetch data from the API
        fetch('https://dummyjson.com/products') 
          .then((response) => {
            if (!response.ok) {
              throw new Error('Failed to fetch products');
            }
            return response.json();
          })
          .then((data) => {
            setProducts(data.products); 
            setLoading(false);
          })
          .catch((error) => {
            setError(error.message); 
            setLoading(false);
          });
      }, []);
    
      if (loading) return <p>Loading...</p>;
      if (error) return <p>Error: {error}</p>;
    
      return (
        <div style={{ padding: '20px' }}>
          <h1>Product List</h1>
          <ul style={{display:'flex',flexWrap:'wrap'}}>
            {products.map((product) => (
              <li key={product.id}  style={{display:'flex', flexDirection:'column'}}>
                <strong>{product.title}</strong> ${product.price}
                <img src={product.thumbnail} alt="" />
              </li>
            ))}
          </ul>
        </div>
      );
}

export default ProductList