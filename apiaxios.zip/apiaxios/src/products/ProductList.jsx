import React, { useState, useEffect } from 'react'
import axios from 'axios'

const ProductList = () => {

    const [products, setProducts] = useState([])
    const [filteredProducts, setFilteredProducts] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');


  

    useEffect(() => {

        axios.get('https://dummyjson.com/products')
            .then((res) => {
                setProducts(res.data.products)
            }).catch((err) => console.log("Data fetching Error"))
        return () => {

        };
    }, []);

    const handleSearch = (e) => {
        const term = e.target.value.toLowerCase();
        setSearchTerm(term);
        // const filtered = products.filter((product) => product.title.toLowerCase().includes(term));
        const filtered = products.filter((product) => product.title.toLowerCase().includes(term))
        setFilteredProducts(filtered)

        console.log(filtered)
    }

    console.log(products)
    return (
        <div>

            <input type="search" name="" id="" value={searchTerm} onChange={handleSearch} />

            <div style={{display:'flex',flexWrap:'wrap',justifyContent:'space-around'}}>
                {
                    filteredProducts.length > 0 ? (

                        filteredProducts.map((pro, index) => (
                            <div key={index} style={{border:'1px solid black',margin:'10px' }}>
                                <h3>{pro.title}</h3>
                                <img src={pro.thumbnail} alt="" />
                                <p>{pro.price}</p>

                            </div>
                        ))

                    ) : (
                        <h2>No Found</h2>
                    )


                }


            </div>

        </div>
    )
}

export default ProductList