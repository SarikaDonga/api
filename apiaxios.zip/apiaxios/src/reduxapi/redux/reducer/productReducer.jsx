const initialState = {
    products: [],
    filteredProducts: [],
    cart: [],
    loading: false,
    error: null,
  };
  
  const productReducer = (state = initialState, action) => {
    switch (action.type) {
      case 'FETCH_PRODUCTS_SUCCESS':
        return {
          ...state,
          products: action.payload,
          filteredProducts: action.payload,
          loading: false,
        };
      case 'FETCH_PRODUCTS_ERROR':
        return {
          ...state,
          error: action.payload,
          loading: false,
        };
      case 'SEARCH_PRODUCTS':
        return {
          ...state,
          filteredProducts: state.products.filter((product) =>
            product.name.toLowerCase().includes(action.payload.toLowerCase())
          ),
        };
      case 'FILTER_BY_CATEGORY':
        return {
          ...state,
          filteredProducts: state.products.filter((product) =>
            product.category === action.payload
          ),
        };
      case 'SORT_PRODUCTS':
        return {
          ...state,
          filteredProducts: [...state.filteredProducts].sort((a, b) => {
            if (action.payload === 'price_asc') return a.price - b.price;
            if (action.payload === 'price_desc') return b.price - a.price;
            return 0;
          }),
        };
      case 'ADD_TO_CART':
        return {
          ...state,
          cart: [...state.cart, action.payload],
        };
      case 'REMOVE_FROM_CART':
        return {
          ...state,
          cart: state.cart.filter((item) => item.id !== action.payload),
        };
      default:
        return state;
    }
  };
  
  export default productReducer;
  